import pyautogui
import keyboard
import time

def cautare_google():#cauta bara de la google si introduce linkul spre un videoclip
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\g.png', confidence=0.7) != None:
        camp_google = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\g.png", confidence=0.7)
        pyautogui.click(camp_google)#da click pe bara
        time.sleep(2)#asteapta 2 secunde
        pyautogui.write("https://www.youtube.com/channel/UCdWmirD6MzuTFeUAtAv4TKQ")#introduce linkul spre videoclip
        pyautogui.press('enter')#dupa ce introduce adresa, apasa enter
       
    else:
        print('Imaginea g NU se afla pe ecran')
              
def cautare_googleabonare():#cauta imaginea cu aboneaza-te
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\a.png', confidence=0.7) != None:
        abonare = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\a.png", confidence=0.7)
        pyautogui.click(abonare)#da click pe aboneaza-te dupa ce il gaseste 
    else:
        print('Imaginea a NU se afla pe ecran')
        
def cautare_googlevideo():#apasa pe videoclipuri
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\v.png', confidence=0.7) != None:
        video = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\v.png", confidence=0.7)
        pyautogui.click(video)
    else:
        print('Imaginea v NU se afla pe ecran')
        
def cautare_video1():#incepe videoclipul 1
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\bara.png', confidence=0.7) != None:
        v1 = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\bara.png", confidence=0.7)
        pyautogui.click(v1)#cauta bara, da click
        time.sleep(2)#asteapta 2 secunde
        pyautogui.write("https://www.youtube.com/watch?v=mDOH2TqPQhw&ab_channel=ForeverYoung")#introduce adresa primului videoclip
        pyautogui.press('enter')#apasa enter
    else:
        print('Imaginea barav1 NU se afla pe ecran')
        
def inapoi():#da pagina inapoi
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\back.png', confidence=0.7) != None:
        back = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\back.png", confidence=0.7)
        pyautogui.click(back) #dupa ce gaseste sageata de back, da click pe ea
    else:
        print('Imaginea back NU se afla pe ecran')
        
def cautare_video2():#incepe videoclipul 2
    if pyautogui.locateOnScreen(r'C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\bara.png', confidence=0.7) != None:
        v2 = pyautogui.locateOnScreen(r"C:\Users\nicol\OneDrive\Desktop\marina\an 3\inteligenta artificiala\sem\4\bara.png", confidence=0.7)
        pyautogui.click(v2)#dupa ce gaseste bara, da ckick pe ea
        time.sleep(2)#asteapta 2 secunde
        pyautogui.write("https://www.youtube.com/watch?v=jfjrZ3LKU8g&ab_channel=ForeverYoung")#introduce adresa videoclipului 2
        pyautogui.press('enter')#apasa enter
    else:
        print('Imaginea barav2 NU se afla pe ecran') 
                   
time.sleep(2)#asteapta 2 secunde
cautare_google()#cauta bara de la google si deschide pagina de pe yt
time.sleep(7)#asteapta 7 secunde

cautare_googleabonare()#apasa pe abonare
time.sleep(7)#asteapta 7 secunde

cautare_googlevideo()#deschide videoclipurile de pe pagina
time.sleep(5)#asteapta 5 secunde

cautare_video1()#deschide videoclipul 1
time.sleep(10)#asteapta 10 secunde

inapoi()#da inapoi pagina, la videoclipuri
time.sleep(5)#asteapta 5 secunde

cautare_video2()#deschide videoclipul 2
time.sleep(10)#asteapta 10 secunde

inapoi()#da inapoi pagina, la videoclipuri